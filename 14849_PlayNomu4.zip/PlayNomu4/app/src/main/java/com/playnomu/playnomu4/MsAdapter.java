package com.playnomu.playnomu4;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MsAdapter extends RecyclerView.Adapter<MsAdapter.MsViewHolder> {

    private Context mContext;
    private ArrayList<MsItem> mMsList;
    public MsAdapter(Context context, ArrayList<MsItem> msList){
        mContext = context;
        mMsList = msList;
    }

    @Override
    public MsAdapter.MsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.ms_item, parent, false);
        return new MsAdapter.MsViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MsAdapter.MsViewHolder holder, int position) {
        final MsItem currentItem = mMsList.get(position);
        final int imageUrl = currentItem.getmImageUrl();
        final String nama = currentItem.getmNama();
        final String kategori = currentItem.getmKategori();
        final int detail = currentItem.getmDetail();


        holder.mKategori.setText(kategori);
        holder.mNama.setText(nama);
        holder.mImageView.setImageResource(imageUrl);

        holder.linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, DetailActivity.class);
                intent.putExtra("namaKopi", nama);
                intent.putExtra("asalKopi", kategori);
                intent.putExtra("imageKopi", imageUrl);
                intent.putExtra("detailKopi", detail);

                mContext.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return mMsList.size();
    }

    public class MsViewHolder extends RecyclerView.ViewHolder {
        public ImageView mImageView;
        public TextView mNama;
        public TextView mKategori;
        public TextView mDetail;
        LinearLayout linear;

        public MsViewHolder(View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.image_view);
            mNama = itemView.findViewById(R.id.tv_nama);
            mKategori = itemView.findViewById(R.id.tv_asal);
            mDetail = itemView.findViewById(R.id.tv_deskripsi);
            linear = itemView.findViewById(R.id.linear);

        }
    }
}
