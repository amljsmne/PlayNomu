package com.playnomu.playnomu4;

public class JuiceItem {
    private String mKategori, mNama;
    private int mImageUrl, mDetail;

    public void setmKategori(String mKategori){
        this.mKategori = mKategori;
    }

    public void setmDetail(int mDetail){
        this.mDetail = mDetail;
    }

    public void setmImageUrl(int mImageUrl){
        this.mImageUrl = mImageUrl;
    }

    public void setmNama(String mNama){
        this.mNama = mNama;
    }

    public  int getmImageUrl(){
        return mImageUrl;
    }

    public int getmDetail() {
        return mDetail;
    }

    public String getmNama() {
        return mNama;
    }

    public String getmKategori() {
        return mKategori;
    }
}
