package com.playnomu.playnomu4;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class milkshake extends AppCompatActivity {
    private RecyclerView rvKopi;
    private MsAdapter msAdapter;
    private ArrayList<MsItem> msList;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_milkshake);
        getSupportActionBar().setTitle("Milkshake Recipes");

        db = new Database(this);

        rvKopi = findViewById(R.id.recycler_view);
        rvKopi.setHasFixedSize(true);
        rvKopi.setLayoutManager(new LinearLayoutManager(this));
        msList = new ArrayList<>();

        msList.addAll(db.getListDa());
        showRecyclerList();
    }

    private void showRecyclerList() {
        msAdapter = new MsAdapter(milkshake.this, msList);
        rvKopi.setAdapter(msAdapter);
    }
}
