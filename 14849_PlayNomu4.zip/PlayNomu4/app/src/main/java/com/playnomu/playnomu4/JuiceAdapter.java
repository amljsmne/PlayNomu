package com.playnomu.playnomu4;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class JuiceAdapter extends RecyclerView.Adapter<JuiceAdapter.JuiceViewHolder> {
    private Context mContext;
    private ArrayList<JuiceItem> mJuiceList;

    public JuiceAdapter(Context context, ArrayList<JuiceItem> juiceList){
        mContext = context;
        mJuiceList = juiceList;
    }
    @Override
    public JuiceViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.juice_item, parent, false);
        return new JuiceAdapter.JuiceViewHolder(v);
    }

    @Override
    public void onBindViewHolder(JuiceViewHolder holder, int position) {
        final JuiceItem currentItem = mJuiceList.get(position);
        final int imageUrl = currentItem.getmImageUrl();
        final String nama = currentItem.getmNama();
        final String kategori = currentItem.getmKategori();
        final int detail = currentItem.getmDetail();


        holder.mKategori.setText(kategori);
        holder.mNama.setText(nama);
        holder.mImageView.setImageResource(imageUrl);

        holder.linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, DetailActivity.class);
                intent.putExtra("namaKopi", nama);
                intent.putExtra("asalKopi", kategori);
                intent.putExtra("imageKopi", imageUrl);
                intent.putExtra("detailKopi", detail);

                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mJuiceList.size();
    }

    public class JuiceViewHolder extends RecyclerView.ViewHolder {
        public ImageView mImageView;
        public TextView mNama;
        public TextView mKategori;
        public TextView mDetail;
        LinearLayout linear;

        public JuiceViewHolder(View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.image_view);
            mNama = itemView.findViewById(R.id.tv_nama);
            mKategori = itemView.findViewById(R.id.tv_asal);
            mDetail = itemView.findViewById(R.id.tv_deskripsi);
            linear = itemView.findViewById(R.id.linear);

        }
    }
}
