package com.playnomu.playnomu4;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    ImageView imageView;
    TextView nama,kategori, detail;
    String namaKopi, asalKopi;
    int image, detailKopi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().setTitle("Recipe Detail");

        imageView = findViewById(R.id.image_view_detail);
        nama = findViewById(R.id.tv_nama_detail);
        kategori = findViewById(R.id.tv_asal_detail);
        detail = findViewById(R.id.tv_deskripsi_detail);

        Intent intent2 = getIntent();
        namaKopi = intent2.getStringExtra("namaKopi");
        asalKopi = intent2.getStringExtra("asalKopi");
        image = intent2.getIntExtra("imageKopi", 0);
        detailKopi= intent2.getIntExtra("detailKopi", 0);

        String cara = getResources().getString(detailKopi);

        nama.setText(namaKopi);
        kategori.setText("Category : " + asalKopi);
        imageView.setImageResource(image);
        detail.setText(cara);

    }
}
