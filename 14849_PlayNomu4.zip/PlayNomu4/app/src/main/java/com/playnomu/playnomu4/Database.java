package com.playnomu.playnomu4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collection;

public class Database extends SQLiteOpenHelper{
    final static String DB_NAME = "db_nomu";

    public Database(Context context){
        super(context,DB_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        String sql = "CREATE TABLE IF NOT EXISTS tbl_coffee(id INTEGER PRIMARY KEY AUTOINCREMENT, nama TEXT, " + "kategori TEXT, img BLOB, deskripsi int)";
        db.execSQL(sql);

        ContentValues values = new ContentValues();
        values.put("nama", "Iced Coffee");
        values.put("kategori", "Coffee");
        values.put("img", R.drawable.kp1);
        values.put("deskripsi", R.string.kp1);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Cappucino");
        values.put("kategori", "Coffee");
        values.put("img", R.drawable.kp2);
        values.put("deskripsi", R.string.kp2);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Caramel Macchiatto");
        values.put("kategori", "Coffee");
        values.put("img", R.drawable.kp3);
        values.put("deskripsi", R.string.kp3);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Raspberry Banna Smothie");
        values.put("kategori", "Juice");
        values.put("img", R.drawable.jc1);
        values.put("deskripsi", R.string.jc1);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Beet Root Juice");
        values.put("kategori", "Juice");
        values.put("img", R.drawable.jc2);
        values.put("deskripsi", R.string.jc2);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Red Plum Juice");
        values.put("kategori", "Juice");
        values.put("img", R.drawable.jc3);
        values.put("deskripsi", R.string.jc3);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Oreo Milkshake");
        values.put("kategori", "Milkshake");
        values.put("img", R.drawable.oreomilkshake);
        values.put("deskripsi", R.string.ms1);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Rainbow Milkshake");
        values.put("kategori", "Milkshake");
        values.put("img", R.drawable.ms2);
        values.put("deskripsi", R.string.ms2);
        db.insert("tbl_coffee","nama",values);

        values.put("nama", "Kitkat Milkshake");
        values.put("kategori", "Milkshake");
        values.put("img", R.drawable.ms3);
        values.put("deskripsi", R.string.ms3);
        db.insert("tbl_coffee","nama",values);
    }


    public ArrayList<CoffeeItem> getListData(){
        CoffeeItem kopi = null;
        ArrayList<CoffeeItem> list = new ArrayList<>();
        String query = "select * from tbl_coffee where kategori='Coffee'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()){
            do{
                kopi = new CoffeeItem();
                kopi.setmNama(cursor.getString(1));
                kopi.setmKategori(cursor.getString(2));
                kopi.setmImageUrl(cursor.getInt(3));
                kopi.setmDetail(cursor.getInt(4));
                list.add(kopi);
            }while(cursor.moveToNext());
        }

        return list;
    }

    public ArrayList<JuiceItem> getListDat(){
        JuiceItem kopi = null;
        ArrayList<JuiceItem> list2 = new ArrayList<>();
        String query = "select * from tbl_coffee where kategori='Juice'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()){
            do{
                kopi = new JuiceItem();
                kopi.setmNama(cursor.getString(1));
                kopi.setmKategori(cursor.getString(2));
                kopi.setmImageUrl(cursor.getInt(3));
                kopi.setmDetail(cursor.getInt(4));
                list2.add(kopi);
            }while(cursor.moveToNext());
        }

        return list2;
    }

    public ArrayList<MsItem> getListDa(){
        MsItem kopi = null;
        ArrayList<MsItem> list3 = new ArrayList<>();
        String query = "select * from tbl_coffee where kategori='Milkshake'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()){
            do{
                kopi = new MsItem();
                kopi.setmNama(cursor.getString(1));
                kopi.setmKategori(cursor.getString(2));
                kopi.setmImageUrl(cursor.getInt(3));
                kopi.setmDetail(cursor.getInt(4));
                list3.add(kopi);
            }while(cursor.moveToNext());
        }

        return list3;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS tbl_soal");
        onCreate(db);

    }
}
