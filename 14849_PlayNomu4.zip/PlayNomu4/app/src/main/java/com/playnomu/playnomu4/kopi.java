package com.playnomu.playnomu4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;

import java.util.ArrayList;

public class kopi extends AppCompatActivity {
   private RecyclerView rvKopi;
   private CoffeeAdapter coffeeAdapter;
   private ArrayList<CoffeeItem> coffeeList;
private Database db;
   @Override
    protected void onCreate(Bundle savedInstanceState){
       super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_kopi);
       getSupportActionBar().setTitle(R.string.resep_kopi);
      db = new Database(this);

       rvKopi = findViewById(R.id.recycler_view);
       rvKopi.setHasFixedSize(true);
       rvKopi.setLayoutManager(new LinearLayoutManager(this));
       coffeeList = new ArrayList<>();

       coffeeList.addAll(db.getListData());
       showRecyclerList();
   }

    private void showRecyclerList() {
       coffeeAdapter = new CoffeeAdapter(kopi.this, coffeeList);
       rvKopi.setAdapter(coffeeAdapter);
    }
}
