package com.playnomu.playnomu4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;

public class home extends AppCompatActivity {

        private DrawerLayout dl;
        private ActionBarDrawerToggle t;
        private NavigationView nv;
        private ImageButton btnjuice,btnkopi,btnms,btntea,btnchoco,btnherb,btntrad;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_home);
            getSupportActionBar().setTitle("Home");

            btnjuice = findViewById(R.id.juice);
            btnjuice.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(home.this, juice.class);
                    startActivity(i);
                }
            });

            btnkopi = findViewById(R.id.kopi);
            btnkopi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent a = new Intent(home.this, kopi.class);
                    startActivity(a);
                }
            });

            btnms = findViewById(R.id.milkshake);
            btnms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent b = new Intent(home.this, milkshake.class);
                    startActivity(b);
                }
            });

            btntea = findViewById(R.id.tea);
            btntea.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(home.this, "Coming Soon", Toast.LENGTH_SHORT).show();
                }
            });

            btnchoco = findViewById(R.id.choco);
            btnchoco.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(home.this, "Coming Soon", Toast.LENGTH_SHORT).show();
                }
            });

            btnherb = findViewById(R.id.herb);
            btnherb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(home.this, "Coming Soon", Toast.LENGTH_SHORT).show();
                }
            });

            btntrad = findViewById(R.id.trad);
            btntrad.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(home.this, "Coming Soon", Toast.LENGTH_SHORT).show();
                }
            });



            dl = (DrawerLayout) findViewById(R.id.activity_nav);
            t = new ActionBarDrawerToggle(this, dl, R.string.Open, R.string.Close);

            dl.addDrawerListener(t);
            t.syncState();

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

            nv = (NavigationView) findViewById(R.id.nv);
            nv.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    int id = item.getItemId();
                    switch (id) {

                        case R.id.home:
                            Intent intent = new Intent(home.this, home.class);
                            startActivity(intent);
                            break;
                        case R.id.profile:
                            Intent intent22 = new Intent(home.this, profile.class);
                            startActivity(intent22);
                            break;
                        case R.id.about:
                            Intent intent5 = new Intent(home.this, about.class);
                            startActivity(intent5);
                            break;
                        case R.id.logout:
                            Intent intent6 = new Intent(home.this, MainActivity.class);
                            startActivity(intent6);
                            break;
                        default:

                    }
                    return true;
                }
            });

        }

}
