package com.playnomu.playnomu4;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class register extends AppCompatActivity {
    private Button btnreg;
    private EditText emtxt;
    private EditText pwtxt;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        emtxt = (EditText) findViewById(R.id.email);
        pwtxt = (EditText) findViewById(R.id.pass);
        firebaseAuth = FirebaseAuth.getInstance();
        getSupportActionBar().setTitle("Register");

    }
    public void submit_Click(View v) {
        final ProgressDialog progressDialog = ProgressDialog.show(register.this, "Please wait...", "Processing...", true);
        (firebaseAuth.createUserWithEmailAndPassword(emtxt.getText().toString(), pwtxt.getText().toString())).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(Task<AuthResult> task) {
                progressDialog.dismiss();

                if (task.isSuccessful()) {
                    Toast.makeText(register.this, "Registration sucecessful", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(register.this, MainActivity.class);
                    startActivity(i);
                } else {
                    Log.e("ERROR", task.getException().toString());
                    Toast.makeText(register.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}

